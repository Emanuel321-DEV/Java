package complemento2;
public class Complemento2 {
    public String toBinary(int number){
        String result = "";
        while(number/2 != 0){
            
        }
    
        return "";
    }
}